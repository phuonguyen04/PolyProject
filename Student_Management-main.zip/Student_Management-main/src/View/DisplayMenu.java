package View;

import java.util.ArrayList;

/**
 *
 * @author phamm
 */
public class DisplayMenu extends Menu {
    public DisplayMenu(ArrayList mc, String td) {
        super(mc, td);
    }

    @Override
    public void execute(int n) {
    }
}
