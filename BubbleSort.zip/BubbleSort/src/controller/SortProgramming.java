/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Model.Element;
import model.Algorithm;
import controller.Validation;
import view.Menu;

/**
 *
 * @author ACER
 */
public class SortProgramming extends Menu<String> {

    static String[] mc = {"Sort array by Bubble Sort", "Exit"};

    Algorithm algorithm = new Algorithm();
    Validation val = new Validation();
    protected int[] array;
    protected int size_array;

    public SortProgramming(Element element) {
        super("PROGRAMMING", mc);
        size_array = element.getSize_array();
        array = element.getArray();
    }

    @Override
    public void execute(int ch) {
        switch (ch) {
            case 1:
                System.out.println("Unsorted array: ");
        val.display(array);
                algorithm.buddleSort(array);
                System.out.println("\nSorted array by Bubble Sort: ");
                val.display(array);
                System.out.println("");
                break;
            case 2:
                System.out.println("Exit successfully!");
                System.exit(0);
                break;
        }
    }
}
